/* 仕上げ用：.ec-reveal をスクロールでやわらかく表示 */
(function(){
  var els=[].slice.call(document.querySelectorAll('.ec-reveal'));
  if(!els.length)return;
  var reduce=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
  if(reduce||!('IntersectionObserver' in window)){els.forEach(function(e){e.classList.add('is-in')});return;}
  var io=new IntersectionObserver(function(es){es.forEach(function(en){if(en.isIntersecting){var d=+(en.target.dataset.ecDelay||0);setTimeout(function(){en.target.classList.add('is-in')},d);io.unobserve(en.target);}})},{rootMargin:'0px 0px -8% 0px',threshold:.08});
  els.forEach(function(e){io.observe(e)});
})();

/* ヒーローの3人を1人ずつ動かす：同じ画像を3枚重ね、それぞれ1人分だけ見せる */
(function(){
  var art=document.querySelector('.hero .hero-art');if(!art)return;
  var img=art.querySelector('img');if(!img||art.querySelector('.ec-trio'))return;
  var box=document.createElement('div');box.className='ec-trio';box.setAttribute('aria-hidden','true');
  [['0 66% 0 0','19%'],['0 36% 0 34%','48%'],['0 0 0 64%','78%']].forEach(function(c,i){
    var p=document.createElement('img');p.src=img.currentSrc||img.src;p.alt='';p.className='ec-p ec-p'+(i+1);
    p.style.clipPath='inset('+c[0]+')';p.style.transformOrigin=c[1]+' 100%';box.appendChild(p);
  });
  img.classList.add('ec-base');img.parentNode.insertBefore(box,img.nextSibling);
  art.classList.add('ec-live');
})();
/* 11/15 先頭へ戻るボタン */
(function(){var f=function(){document.body.classList.toggle('scrolled-far',scrollY>900)};addEventListener('scroll',f,{passive:true});f()})();
